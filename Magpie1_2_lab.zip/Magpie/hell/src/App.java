public class App {
    public static void main(String[] args) throws Exception {
      /*  mixUp("Math", "Computer");
       mixUp("ABC", "12345");*/
     findLast("I enjoy challenging code.", "e");
     findLast(Ha Ha Ha", "ha");
      
    }

  
}
